#26 November 2023
#CTI-110 P5HW - Math Quiz
#Curtis Cooper
"""
Get user input
Evaluate input
Call function 
Function evaluates input
Displays results
"""
import menu

menu = menu.menu()

if __name__ == '__main__':
  ()
  
  
